// backend/src/routes/auth.routes.js
const express = require('express');
const passport = require('passport');
const jwt = require('jsonwebtoken');
require('../utils/passport-google')(); // initialize Google strategy
const router = express.Router();

// Start Google OAuth
router.get(
  '/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

// Google callback
router.get(
  '/google/callback',
  passport.authenticate('google', { session: false, failureRedirect: '/auth/failure' }),
  (req, res) => {
    const user = req.user;

    // generate JWT using MongoDB _id
    const payload = {
      sub: user._id.toString(), // important: string _id
      role: user.role,
      email: user.email,
    };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '8h' });

    res.json({
      message: 'Login successful',
      token,
      user: {
        _id: user._id, // use _id
        name: user.name,
        email: user.email,
        role: user.role,
      },
    });
  }
);

// Failure route
router.get('/failure', (req, res) => {
  res.status(401).json({ message: 'OAuth login failed' });
});

module.exports = router;
